import React from 'react'
export default function OrderComplete(){ return (<section className="card"><h1>Pedido completado</h1><p>Gracias por tu compra. Revisa tus órdenes en "Mi cuenta".</p></section>) }
